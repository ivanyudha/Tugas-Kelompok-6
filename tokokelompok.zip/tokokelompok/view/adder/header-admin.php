    <div class="header header-fixed np" style="background: linear-gradient(to bottom, #43a6df, #43d0e9); color:white;">    
        <nav class="nav header-nav nav-x">
            <ul>
                
            </ul>
            <ul style="float:right">
                <li><?php echo $_SESSION['user'] ?></li>
            </ul>
        </nav>
    </div>