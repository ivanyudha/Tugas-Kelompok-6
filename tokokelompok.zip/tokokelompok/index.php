<?php
    header("location:admin.php?page=home&&subpage=dashboard");
?>